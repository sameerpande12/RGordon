echo "============= TEST FOR 2 RUNS"
./multi-launch.sh www.facebook.com 2
echo "============= TEST FOR 5 RUNS"
./multi-launch.sh www.facebook.com 5
echo "============= TEST FOR 7 RUNS"
./multi-launch.sh www.facebook.com 7
echo "============= TEST FOR 10 RUNS"
./multi-launch.sh www.facebook.com 10
echo "============= TEST FOR 15 RUNS"
./multi-launch.sh www.facebook.com 15
echo "============= TEST FOR 25 RUNS"
./multi-launch.sh www.facebook.com 25
echo "============= TEST FOR 50 RUNS"
./multi-launch.sh www.facebook.com 50
echo "============= TEST FOR 100 RUNS"
./multi-launch.sh www.facebook.com 100
