sudo killall wget prober launch
sudo iptables --flush
